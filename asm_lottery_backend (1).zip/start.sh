#!/bin/bash
echo "启动 MongoDB..."
sudo service mongod start
echo "启动后端服务..."
npm install
node server.js