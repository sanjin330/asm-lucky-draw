const prizes = [
  { label: "Rs. 100", weight: 30 },
  { label: "Rs. 234", weight: 25 },
  { label: "Rs. 345", weight: 20 },
  { label: "Rs. 456", weight: 11 },
  { label: "Rs. 777", weight: 8 },
  { label: "Rs. 999", weight: 7 },
  { label: "Rs. 1666", weight: 4 },
  { label: "Rs. 7654", weight: 1 }
];
const canvas = document.getElementById("wheelcanvas");
const ctx = canvas.getContext("2d");
const radius = canvas.width / 2;
const spinBtn = document.getElementById("spin");
const result = document.getElementById("result");
const prizeSpan = document.getElementById("prize");

function drawWheel() {
  let startAngle = 0;
  const totalWeight = prizes.reduce((sum, p) => sum + p.weight, 0);
  prizes.forEach((prize, i) => {
    const angle = (2 * Math.PI * prize.weight) / totalWeight;
    ctx.beginPath();
    ctx.moveTo(radius, radius);
    ctx.arc(radius, radius, radius, startAngle, startAngle + angle);
    ctx.fillStyle = `hsl(${(i * 360) / prizes.length}, 80%, 70%)`;
    ctx.fill();
    ctx.fillStyle = "#000";
    ctx.translate(radius, radius);
    ctx.rotate(startAngle + angle / 2);
    ctx.textAlign = "right";
    ctx.font = "16px Arial";
    ctx.fillText(prize.label, radius - 10, 5);
    ctx.rotate(-startAngle - angle / 2);
    ctx.translate(-radius, -radius);
    startAngle += angle;
  });
}
drawWheel();

function spinWheel() {
  const totalWeight = prizes.reduce((sum, p) => sum + p.weight, 0);
  let rnd = Math.random() * totalWeight;
  let selected;
  for (let i = 0; i < prizes.length; i++) {
    rnd -= prizes[i].weight;
    if (rnd <= 0) {
      selected = prizes[i];
      break;
    }
  }
  const angle = Math.random() * 360 + 720;
  canvas.style.transition = "transform 5s ease-out";
  canvas.style.transform = `rotate(${angle}deg)`;
  setTimeout(() => {
    prizeSpan.textContent = selected.label;
    result.classList.remove("hidden");
  }, 5200);
}
spinBtn.addEventListener("click", spinWheel);